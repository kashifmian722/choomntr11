# 1.0.5
- Fix Fonteinbindung der Inter-Font
- Kompatibilität-Fix für Shopware 6.3.5.
- Styling Anpassungen für 'header' und 'product-detail page'

# 1.0.4
- Cross Selling Slider optimiert
- Newsletter fix
- Styling fixes
- Checkout optimiert
- Account Ansicht optimiert
- Mobile Styling fixes

# 1.0.3
- Theme.json Reihenfolge optimiert
- Styling fixes
- Code refactor
- Fixed Passwort validation überlappt
- Textfarbe vom Account-Bestellungen-Aufklappen-Button anpassbar
- Account doppelte Ausgabe von Eingabefeldern

# 1.0.2
- Refactor Product Box Styling
- Option zum darstellen einer simplen Variante des Grundpreises in der Produkt Box hinzugefügt

# 1.0.1
- JS fixes

# 1.0.0
- Initiale Plugin Version
