import './module/wkpos-outlet';
import './module/wkpos-user';
import './module/wkpos-order';
import './module/wkpos-product';
import './init/api-service.init';