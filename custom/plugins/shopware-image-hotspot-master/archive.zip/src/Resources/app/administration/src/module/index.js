Shopware.Module.register('sas-image-hotspot', {
    type: 'plugin',
    name: 'sas-image-hotspot',
    title: 'sas-image-hotspot-map.general.title',
    description: 'sas-image-hotspot-map.general.description',
    color: '#62ff80',
    icon: 'default-shopping-paper-bag',
});
