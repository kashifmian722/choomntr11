import './component/sas-image-hotspot';
import './component/sas-image-hotspot-map';
import './component/sas-image-hotspot-modal';
import './module/index';
import './extension/component/media/sw-media-preview-v2';
import './extension/component/media/sw-media-library';
import './extension/component/media/sw-media-media-item';
import './extension/component/product/sw-product-image';
