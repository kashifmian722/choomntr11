<?php declare(strict_types=1);

namespace fourtwosix\SearchWithCam;

use Shopware\Core\Framework\Plugin;
use Shopware\Core\Framework\Plugin\Context\InstallContext;
use Shopware\Core\Framework\Plugin\Context\UninstallContext;

class fourtwosixSearchWithCam extends Plugin
{
    public function install(InstallContext $context): void {

    }

    public function uninstall(UninstallContext $context): void {

    }
}