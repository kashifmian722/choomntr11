# 1.0.0
- Erstveröffentlichung.

# 1.0.1
- zxing-Bibliothek jetzt importiert.