# 1.0.0
- First published.

# 1.0.1
- zxing library imported now.